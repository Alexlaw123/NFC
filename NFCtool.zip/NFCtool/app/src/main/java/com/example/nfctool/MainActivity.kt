package com.example.nfctool

import android.app.PendingIntent
import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcEvent
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.nfctool.ui.theme.NFCToolTheme
import android.util.Log

class MainActivity : ComponentActivity() {

    private lateinit var nfcAdapter: NfcAdapter
    private var isWriteMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("NFC", "NFC begin onCreate")
        // 打印 intent 和 intent.action
        Log.d("NFC", "LZD Intent: $intent")
        Log.d("NFC", "LZD Intent action: ${intent?.action}")

        if (intent != null && NfcAdapter.ACTION_NDEF_DISCOVERED == intent.action) {
            Log.d("NFC", "LZD NFC Intent detected")
            val tag = intent.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG)
            tag?.let {
                Log.d("NFC", "LZD Tag detected: ${tag.id}")
                // Your reading logic here
            }
        }
        enableEdgeToEdge()
        setContent {
            NFCToolTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    NFCButtons(
                        onReadClick = {
                            isWriteMode = false
                            Toast.makeText(this, "Ready to read NFC tag", Toast.LENGTH_SHORT).show()
                        },
                        onWriteClick = {
                            isWriteMode = true
                            Toast.makeText(this, "Tap NFC tag to write", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Log.d("NFC", "onResume: Enabling foreground dispatch")

        // Enable foreground dispatch here
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        if (nfcAdapter != null) {
            Log.d("NFC", "onResume: foreground dispatch is OK ")
        }
        val intent = Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
        nfcAdapter.enableForegroundDispatch(this, pendingIntent, null, null)

        Log.d("NFC", "LZD onResume: Foreground dispatch enabled")

    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)

        val tag = intent?.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG)
        if (tag != null) {
            if (isWriteMode) {
                writeNfcTag(tag)
            } else {
                readNfcTag(tag)
            }
        }
    }

    private fun writeNfcTag(tag: Tag) {
        val ndef = Ndef.get(tag)
        if (ndef != null) {
            ndef.connect()
            val message = NdefMessage(
                arrayOf(NdefRecord.createTextRecord("en", "Hello from Android!"))
            )
            ndef.writeNdefMessage(message)
            ndef.close()
            Toast.makeText(this, "NFC tag written", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "NDEF not supported", Toast.LENGTH_SHORT).show()
        }
    }

    private fun readNfcTag(tag: Tag) {
        val ndef = Ndef.get(tag)
        if (ndef != null) {
            ndef.connect()
            val ndefMessage = ndef.ndefMessage
            val message = ndefMessage.records[0].payload.toString(Charsets.UTF_8)
            Toast.makeText(this, "Read content: $message", Toast.LENGTH_SHORT).show()
            ndef.close()
        } else {
            Toast.makeText(this, "NDEF not supported", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onPause() {
        super.onPause()
        // Disable foreground dispatch here
        Log.d("NFC", "onPause: Disabling foreground dispatch")

        val nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        nfcAdapter.disableForegroundDispatch(this)
        Log.d("NFC", "onPause: Foreground dispatch disabled")
        if (nfcAdapter != null) {
            Log.d("NFC", "LZD onPause: foreground dispatch is OK ")
        }

    }
}

@Composable
fun NFCButtons(
    onReadClick: () -> Unit,
    onWriteClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Button(onClick = onReadClick) {
            Text(text = "Read NFC")
        }
        Button(onClick = onWriteClick) {
            Text(text = "Write NFC")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun NFCButtonsPreview() {
    NFCToolTheme {
        NFCButtons(onReadClick = {}, onWriteClick = {})
    }
}
